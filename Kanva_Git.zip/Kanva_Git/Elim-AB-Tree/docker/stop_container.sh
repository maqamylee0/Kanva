#!/bin/bash

docker stop setbench
