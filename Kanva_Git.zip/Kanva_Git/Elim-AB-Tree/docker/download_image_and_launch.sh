#!/bin/bash

./download_image.sh
./launch_downloaded_image.sh
