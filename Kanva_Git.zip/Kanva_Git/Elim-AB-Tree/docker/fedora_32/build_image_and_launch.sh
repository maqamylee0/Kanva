#!/bin/bash

./build_image.sh
./launch_built_image.sh
