/* 
 * File:   descriptors.h
 * Author: tabrown
 *
 * Created on June 8, 2016, 6:18 PM
 */

#ifndef DESCRIPTORS_H
#define	DESCRIPTORS_H

typedef intptr_t tagptr_t;
typedef intptr_t mutables_t;

#endif	/* DESCRIPTORS_H */

