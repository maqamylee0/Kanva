#!/bin/bash

docker ps -a
