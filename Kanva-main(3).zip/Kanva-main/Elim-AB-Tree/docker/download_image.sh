#!/bin/bash

docker pull trbot86/setbench
